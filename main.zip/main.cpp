// =================================================================================================
// ModbusClient: Copyright 2020 by Michael Harwerth, Bert Melis and the contributors to ModbusClient
//               MIT license - see license.md for details
// =================================================================================================

#include <Arduino.h>
// #include "ModbusServerWiFi.h"
#include "ModbusServerEthernet.h"

#if TCPMODE == ETHERNETMODE
// Variables for Ethernet.h
byte mac[] = { 0x30, 0x2B, 0x2D, 0x3E, 0xF6, 0x88 };  // Partly set, last 3 bytes from settings.dat
// W5500 reset pin 
#define RESET_P GPIO_NUM_26
// Set up a Modbus server
ModbusServerEthernet MBserver;
#else
// Variables for Wifi.h
char ssid[] = "FritzGandhi";
char pass[] = "MahatmaNetzwerk";
// Set up a Modbus server
ModbusServerWiFi MBserver;
#endif

IPAddress lIP;                      // IP address after Ethernet/WiFi.begin()

const uint8_t MY_SERVER(1);
uint16_t memo[128];                 // Test server memory

// Worker function for serverID=1, function code 0x03
ResponseType FC03(uint8_t serverID, uint8_t functionCode, uint16_t dataLen, uint8_t *data) {
  uint16_t addr = 0;        // Start address to read
  uint16_t wrds = 0;        // Number of words to read

  // Get addr and words from data array. Values are MSB-first, getValue() will convert to binary
  // Returned: number of bytes eaten up 
  uint16_t offs = getValue(data, dataLen, addr);
  offs += getValue(data + offs, dataLen - offs, wrds);

  Serial.printf("Get %d words at %d\n", wrds, addr);
  
  // address valid?
  if (!addr || addr > 128) {
    // No. Return error response
    return MBserver.ErrorResponse(ILLEGAL_DATA_ADDRESS);
  }

  // Modbus address is 1..n, memory address 0..n-1
  addr--;

  // Number of words valid?
  if (!wrds || (addr + wrds) > 127) {
    // No. Return error response
    return MBserver.ErrorResponse(ILLEGAL_DATA_ADDRESS);
  }

  // Data buffer for returned values. +1 for the leading length byte!
  uint8_t rdata[wrds * 2 + 1];

  // Set length byte
  rdata[0] = wrds * 2;
  offs = 1;

  // Loop over all words to be sent
  for (uint16_t i = 0; i < wrds; i++) {
    // Add word MSB-first to response buffer
    offs += addValue(rdata + offs, wrds * 2 - offs + 1, memo[addr + i]);
  }

  // Return the data response
  return MBserver.DataResponse(wrds * 2 + 1, rdata);
}

#if TCPMODE == ETHERNETMODE
// Reset W5500 module
void WizReset() {
    Serial.print("Resetting Wiz W5500 Ethernet Board...  ");
    pinMode(RESET_P, OUTPUT);
    digitalWrite(RESET_P, HIGH);
    delay(250);
    digitalWrite(RESET_P, LOW);
    delay(50);
    digitalWrite(RESET_P, HIGH);
    delay(350);
    Serial.print("Done.\n");
}
#endif

void setup() {
// Init Serial
  Serial.begin(115200);
  while (!Serial) {}
  Serial.println("__ OK __");

  // Register the worker function with the Modbus server
  MBserver.registerWorker(MY_SERVER, READ_HOLD_REGISTER, &FC03);
  
  // Register the worker function again for another FC
  MBserver.registerWorker(MY_SERVER, READ_INPUT_REGISTER, &FC03);
  
  #if TCPMODE == ETHERNETMODE
  // SPI CS line is GPIO_NUM_5
  Ethernet.init(GPIO_NUM_5);
  // Hard boot W5500 module
  WizReset();

  // start the Ethernet connection:
  bool connected = false;
  if (true) // DHCP required?
  {
    if (Ethernet.begin(mac) == 0) 
    {
      Serial.print("Failed to configure Ethernet using DHCP\n");
    }
    else 
    {
      connected = true;
    }
  }
  // Connection established?
  if (!connected)
  {
    // No. Either DHCP was not required or did not work.
    // initialize the Ethernet device not using DHCP:
    Ethernet.begin(mac, IPAddress(192, 168, 178, 73), IPAddress(192, 168, 178, 1), IPAddress(192, 168, 178, 1), IPAddress(255, 255, 255, 0));
    // Check for Ethernet hardware present
    if (Ethernet.hardwareStatus() == EthernetNoHardware) 
    {
      Serial.print("Ethernet shield was not found.  Sorry, can't run without hardware. :(\n");
    }
    else
    {
      if (Ethernet.linkStatus() == LinkOFF) 
      {
        Serial.print("Ethernet cable is not connected.\n");
      }
      else connected = true;
    }
  }

  lIP = Ethernet.localIP();
#else
  WiFi.begin(ssid, pass);
  delay(200);
  int status = WiFi.status();
  while (status != WL_CONNECTED) {
    Serial.print('.');
    WiFi.disconnect(true);
    WiFi.begin(ssid, pass);
    delay(1000);
    status = WiFi.status();
  }

  lIP = WiFi.localIP();
#endif

  // print local IP address:
  Serial.printf("My IP address: %u.%u.%u.%u\n", lIP[0], lIP[1], lIP[2], lIP[3]);

  // Initialize server memory with consecutive values
  for (uint16_t i = 0; i < 128; ++i) {
    memo[i] = (i * 2) << 8 | ((i * 2) + 1);
  }

  // Start the Modbus TCP server
  MBserver.start(502, 4, 0);
}

void loop() {
  static uint32_t statusTime = millis();
  const uint32_t statusInterval(10000);

  // We will be idling around here - all is don in subtasks :D
  if (millis() - statusTime > statusInterval) {
    Serial.printf("%d clients running. Heap=%d\n", MBserver.activeClients(), ESP.getFreeHeap());
    statusTime = millis();
  }
  delay(1000);
}
